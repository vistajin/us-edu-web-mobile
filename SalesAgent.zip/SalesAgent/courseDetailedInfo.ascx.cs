﻿using E_LearningWeb.Bussiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Localization;
using ELearningWeb.Models;
using E_LearningWeb.Models;
using ELearningWeb.Document;
using E_LearningWeb;

namespace E_LearningWeb_Mobile
{
    public partial class courseDetailedInfo : System.Web.UI.UserControl
    {
        protected PagedDataSource pds = new PagedDataSource();
        int pagesize = 10;
        string sortExpression = string.Empty;
        string sortDirection = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            // in mobile.aspx, we set to load this page only when pageId = AGENT_3ND_PAGE_ID
            // but it will still run into here even pageId != AGENT_3ND_PAGE_ID
            if (Request.QueryString["pageId"] != Constant.AGENT_3ND_PAGE_ID)
            {
                return;
            }
            if (!windowsJs.CheckAuthority(Constant.AGENT_PAGE_ID))
            {
                windowsJs.SessionIsNull(this.Page);
                return;
            }

            if (!IsPostBack)
            {
                hiddenCourseID.Value = Request.QueryString["course_Id"];
                ViewState["course_Id"] = Request.QueryString["course_Id"];
                hiddenRegID.Value = Request.QueryString["regID"];
                ViewState["regID"] = Request.QueryString["regID"];
                hiddenStudentUserID.Value = Request.QueryString["studentUserID"];
                ViewState["studentUserID"] = Request.QueryString["studentUserID"];
                lblStudentNameVal.Text = Request.QueryString["studentName"];
                ViewState["studentName"] = Request.QueryString["studentName"];
                lblCourseNameVal.Text = Request.QueryString["courseName"];
                ViewState["courseName"] = Request.QueryString["courseName"];
                //任务信息数据加载
                BindCxInfoData(0);

                // 分页按钮部分初期化
                InitCategory();
            }
        }
        #region 绑定任务信息数据
        /// <summary>
        /// 绑定任务信息数据
        /// </summary>
        private void BindCxInfoData(int pageindex)
        {
            pds.AllowPaging = true;//设置可以分页
            pds.PageSize = pagesize;//每页的项数
            pds.CurrentPageIndex = pageindex;//获取或设置当前页的索引
            if (pageindex != 0)
            {
                pds.CurrentPageIndex = pageindex - 1;
            }
            else
            {
                lblCurr.Text = "1";
            }

            // 魏 2015.06.12 Modify Start
            try
            {
                pds.DataSource = salesAgentManager.GetcourseDetailedInfo(
                    hiddenRegID.Value, hiddenCourseID.Value, hiddenStudentUserID.Value, "", "");                
                dtlCourseDetailInfo.DataSource = pds;//获取数据源
                // dtlCourseDetailInfo.DataKeyNames = new string[] { "QuizScores" };
                dtlCourseDetailInfo.DataBind();//绑定数据
            }
            catch
            {                
                windowsJs.Alert(this.Page, GetResourceString("FailedGetCourseDetails"));
                //windowsJs.Alert(this.Page, "hiddenRegID.Value=" + hiddenRegID.Value + ",hiddenCourseID.Value=" + hiddenCourseID.Value + ",hiddenStudentUserID.Value=" + hiddenStudentUserID.Value);
                return;
            }
            // 魏 2015.06.12 Modify End
        }
        #endregion

        #region 获取记录总数和页数
        /// <summary>
        /// 获取记录总数和页数
        /// </summary>
        private void InitCategory()
        {
            // 数据总数
            //login Login = (login)Session["USER"];
            //login Login = new login();
            //Login.users_userID = "7";
            int recordcount = pds.DataSourceCount;
            //int recordcount = salesAgentManager.GetcourseDetailedInfo(null).Count;
            // 根据数据总数和每页显示的数据数，计算出总页数
            int pagecount = recordcount % pagesize == 0 ? recordcount / pagesize : recordcount / pagesize + 1;
            lblSum.Text = pagecount.ToString();

            //分页各按钮状态设定
            ChangeState();

            //跳转页下拉控件添加页号
            ddlPage.Items.Clear();
            for (int i = 1; i <= pagecount; i++)
            {
                ListItem li = new ListItem();
                li.Value = i.ToString();
                li.Text = i.ToString();

                ddlPage.Items.Add(li);
            }
        }
        #endregion

        #region 跳转页事件
        /// <summary>
        /// 跳转页事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlPage_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindCxInfoData(Convert.ToInt32(ddlPage.SelectedValue));
            lblCurr.Text = ddlPage.SelectedValue.ToString();
            ChangeState();
        }
        #endregion

        #region 按钮状态改变
        /// <summary>
        /// 按钮状态改变事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lbtnFirst_Command(object sender, CommandEventArgs e)
        {
            int temp = 0;
            switch (e.CommandName)
            {
                // "首页"按下
                case "first": lblCurr.Text = "1";
                    lblCurr.Text = "1";
                    ddlPage.SelectedValue = "1";
                    break;
                // "前页"按下
                case "prev":
                    temp = Convert.ToInt32(lblCurr.Text) - 1;
                    lblCurr.Text = temp.ToString();
                    ddlPage.SelectedValue = temp.ToString();
                    break;
                // "下页"按下
                case "next":
                    temp = Convert.ToInt32(lblCurr.Text) + 1;
                    lblCurr.Text = temp.ToString();
                    ddlPage.SelectedValue = temp.ToString();
                    break;
                // "末页"按下
                case "last": lblCurr.Text = lblSum.Text;
                    temp = Convert.ToInt32(lblSum.Text);
                    lblCurr.Text = temp.ToString();
                    ddlPage.SelectedValue = temp.ToString();
                    break;
            }
            // 各按钮状态改变
            ChangeState();
            // 数据再绑定
            BindCxInfoData(Convert.ToInt32(lblCurr.Text));
        }

        /// <summary>
        /// 按钮状态改变
        /// </summary>
        private void ChangeState()
        {
            lbtnFirst.Enabled = true;
            lbtnPrev.Enabled = true;
            lbtnNext.Enabled = true;
            lbtnLast.Enabled = true;
            ddlPage.Enabled = true;

            // 数据总数为0 或1 的情况
            if (lblSum.Text == "0" || lblSum.Text == "1")
            {
                if (lblSum.Text == "0")
                {
                    lblCurr.Text = "0";
                    ddlPage.Enabled = false;
                }
                else
                {
                    lblCurr.Text = "1";
                }
                lbtnFirst.Enabled = false;
                lbtnPrev.Enabled = false;
                lbtnNext.Enabled = false;
                lbtnLast.Enabled = false;
            }
            // 当前页为第一页
            else if (lblCurr.Text == "1")
            {
                lbtnFirst.Enabled = false;
                lbtnPrev.Enabled = false;
            }
            // 当前页为末页
            else if (lblSum.Text == lblCurr.Text)
            {

                lbtnNext.Enabled = false;
                lbtnLast.Enabled = false;
            }

        }
        #endregion
               

        #region ToolTip生成方法
        /// <summary>
        /// ToolTip生成方法
        /// </summary>
        /// <param name="pageindex"></param>
        protected void setToolTip(int index, int length, GridViewRowEventArgs e)
        {
            string strContent = e.Row.Cells[index].Text;
            if (strContent.Length > length)
            {
                e.Row.Cells[index].Text = strContent.Substring(0, length) + "...";
                e.Row.Cells[index].ToolTip = strContent;
            }

        }
        #endregion

        #region 课程名变化时填充学生列表
        /// <summary>
        /// 课程名变化时填充学生列表
        /// </summary>
        /// <param name="pageindex"></param>
        protected void ddlmyCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            //任务信息数据加载
            BindCxInfoData(0);

            // 分页按钮部分初期化
            InitCategory();

        }
        #endregion

        /*
        #region 每页显示数变化时
        /// <summary>
        /// 每页显示数变化时
        /// </summary>
        /// <param name="pageindex"></param>
        protected void ddlPageNum_SelectedIndexChanged(object sender, EventArgs e)
        {
            ViewState["pagesize"] = Convert.ToInt32(ddlPageNum.SelectedItem.Value);
            //读出cookie的值
            HttpCookie cookie1 = Request.Cookies["abc"];
            if (cookie1 != null)
            {
                //cookie1的值不为空直接赋值
                cookie1.Value = ddlPageNum.SelectedItem.Value;
            }
            else
            {
                //cookie1的值为空new对象给cookie1
                cookie1 = new HttpCookie("abc");
                cookie1.Value = ddlPageNum.SelectedItem.Value;
            }
            //设置cookie的生命周期
            cookie1.Expires = DateTime.MaxValue;

            //将Cookie提交到浏览器
            Response.Cookies.Add(cookie1);

            //任务信息数据加载
            BindCxInfoData(0);

            // 分页按钮部分初期化
            InitCategory();
        }
        #endregion        
        #region 排序处理

        /// <summary>
        /// 排序处理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GridViewForStudentCourseInfo_Sorting(object sender, GridViewSortEventArgs e)
        {
            if (dtlCourseDetailInfo.Rows.Count > 0)
            {

                //获取排序数据列
                sortExpression = e.SortExpression.ToString();
                //假定为排序方向为“顺序”
                sortDirection = "ASC";
                // “ASC”与事件参数获取到的排序方向进行比较，进行GridView排序方向参数的修改
                if (sortExpression == this.dtlCourseDetailInfo.Attributes["SortExpression"])
                {
                    //获得下一次的排序状态
                    sortDirection = (this.dtlCourseDetailInfo.Attributes["SortDirection"].ToString() == sortDirection ? "DESC" : "ASC");
                }
                // 重新设定GridView排序数据列及排序方向
                this.dtlCourseDetailInfo.Attributes["SortExpression"] = sortExpression;
                this.dtlCourseDetailInfo.Attributes["SortDirection"] = sortDirection;

                BindCxInfoData(Convert.ToInt32(ddlPage.SelectedValue));

                //SortForImage(sortDirection, sortExpression);
            }
        }
        #endregion
        */
        protected void Item_Bound(Object sender, DataListItemEventArgs e)
        {
            // set background to light gray for odd row
            if (e.Item.ItemType == ListItemType.Item)
            {
                e.Item.BackColor = System.Drawing.Color.LightGray;
            }
            // caculate serial number
            if (e.Item.ItemIndex >= 0)
            {
                Label lblNumber = (Label)e.Item.FindControl("lblSerialNumber");
                int indexID = 0;
                indexID = pds.CurrentPageIndex * pagesize + e.Item.ItemIndex + 1;
                lblNumber.Text = indexID.ToString();
            }
            // set no record display info
            if (e.Item.ItemType == ListItemType.Footer)
            {
                if (pds.Count <= 0)
                {
                    ((Label)e.Item.FindControl("lblNoRecord")).Visible = true;
                }
            }
        }

        protected void BackStudentInfo_Click(object sender, EventArgs e)
        {
            Response.Redirect("mobile.aspx?pageId=" + Constant.AGENT_PAGE_ID);
        }

        private string GetResourceString(String key)
        {
            global::System.Resources.ResourceManager rm = new global::System.Resources.ResourceManager("Resources.global",
                    global::System.Reflection.Assembly.Load("App_GlobalResources"));
            string languageCode = Session["PreferredCulture"].ToString().ToUpper();
            return rm.GetString(key, new global::System.Globalization.CultureInfo(languageCode));
        }

        public string CourseID { get; set; }

        public string Name { get; set; }

        public string courseID { get; set; }
    }
}