﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ELearningWeb.Models;
using E_LearningWeb.Bussiness;
using System.Text;
using System.Data;
using E_LearningWeb.student;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ELearningWeb.Document;
using Localization;
using E_LearningWeb.Models;
using ELearningWeb;

namespace E_LearningWeb_Mobile
{
    public partial class salesAgentStudentCourse : System.Web.UI.UserControl
    {
        protected PagedDataSource pds = new PagedDataSource();
        int pagesize = 10;
        string sortExpression = string.Empty;
        string sortDirection = string.Empty;

        global::System.Resources.ResourceManager rm;

        protected void Page_Load(object sender, EventArgs e)
        {
            // in mobile.aspx, we set to load this page only when pageId = AGENT_2ND_PAGE_ID
            // but it will still run into here even pageId != AGENT_2ND_PAGE_ID
            if (Request.QueryString["pageId"] != Constant.AGENT_2ND_PAGE_ID)
            {
                return;
            }
            if (!windowsJs.CheckAuthority(Constant.AGENT_PAGE_ID) 
                && !windowsJs.CheckAuthority(Constant.MANAGER_PAGE_ID) 
                && !windowsJs.CheckAuthority(Constant.TEACHER_PAGE_ID) 
                && !windowsJs.CheckAuthority(Constant.OFFICER_PAGE_ID)) //Added OFFICER_PAGE_ID by AYZ 2/15/2017            //modified by AYZ 12/24/2016
            {
                windowsJs.SessionIsNull(this.Page);
                return;
            }
            if (!IsPostBack)
            {
                //创建cookie指针变量
                HttpCookie cookie = Request.Cookies["abc"];
                //每页显示条数
                if (cookie == null)
                {
                    ViewState["pagesize"] = pagesize;
                }
                //ViewState["pagesize"] = pagesize;
                //填充每页显示数list
                ddlPageNum.Items.Add(new ListItem("10", "10"));
                ddlPageNum.Items.Add(new ListItem("20", "20"));
                ddlPageNum.Items.Add(new ListItem("40", "40"));
                ddlPageNum.Items.Add(new ListItem("80", "80"));
                ddlPageNum.Items.Add(new ListItem("100", "100"));
                // ddlPageNum.SelectedValue = Convert.ToString(ViewState["pagesize"]);

                rm = new global::System.Resources.ResourceManager("Resources.global",
                    global::System.Reflection.Assembly.Load("App_GlobalResources"));

                ddlStudentName.Items.Add(new ListItem(GetResourceString("select"), ""));

                string loginUserID = Session["userID"].ToString();
                // 已被分配课程的所有学生信息            commented and added by AYZ 12/25/2016
                //List<salesAgentStudentInfo> studentListInfo = salesAgentManager.GetstudentInfo(loginUserID, "U.fName, U.lName", "");
                //string userID = "";
                //foreach (salesAgentStudentInfo studentTemp in studentListInfo)
                //{
                //    if (String.Compare(userID, studentTemp.studentUserID, true) != 0)
                //    { 
                //        ListItem myListItem = new ListItem(studentTemp.student_Name, studentTemp.studentUserID);
                //        ddlStudentName.Items.Add(myListItem);
                //        userID = studentTemp.studentUserID;
                //    }
                //}
                string userID = "";
                List<salesAgentStudentInfo> studentListInfo = new List<salesAgentStudentInfo>();
                if (windowsJs.CheckAuthority(Constant.AGENT_PAGE_ID))
                {
                    studentListInfo = salesAgentManager.GetstudentInfo(loginUserID, "U.fName, U.lName", "");
                }
                else if (windowsJs.CheckAuthority(Constant.MANAGER_PAGE_ID) || windowsJs.CheckAuthority(Constant.OFFICER_PAGE_ID))          //Added OFFICER_PAGE_ID by AYZ 2/15/2017
                {
                    studentListInfo = generalManager.GetUserInfoByType(loginUserID, "STUDENT", "U.fName, U.lName", "");
                }
                else if (windowsJs.CheckAuthority(Constant.TEACHER_PAGE_ID))
                {
                    studentListInfo = generalManager.GetTeacherStudentInfo(loginUserID, "U.fName, U.lName", "");
                }

                foreach (salesAgentStudentInfo studentTemp in studentListInfo)
                {
                    if (String.Compare(userID, studentTemp.studentUserID, true) != 0)
                    {
                        ListItem myListItem = new ListItem(studentTemp.student_Name, studentTemp.studentUserID);
                        ddlStudentName.Items.Add(myListItem);
                        userID = studentTemp.studentUserID;
                    }
                }
            }
            //任务信息数据加载
            BindCxInfoData(0, ddlStudentName.SelectedItem.Value);
            // 分页按钮部分初期化
            InitCategory();
        }

        private string GetResourceString(String key)
        {
            string languageCode = Session["PreferredCulture"].ToString().ToUpper();
            return rm.GetString(key, new global::System.Globalization.CultureInfo(languageCode));
        }

        #region 绑定任务信息数据
        /// <summary>
        /// 绑定任务信息数据
        /// </summary>
        private void BindCxInfoData(int pageindex, string studentUserID)
        {
            pds.AllowPaging = true;//设置可以分页
            HttpCookie cookie = Request.Cookies["abc"];
            if (cookie != null)
            {
                pagesize = Convert.ToInt32(cookie.Value);
                pds.PageSize = pagesize;//每页的项数
            }
            pds.CurrentPageIndex = pageindex;//获取或设置当前页的索引
            if (pageindex != 0)
            {
                pds.CurrentPageIndex = pageindex - 1;
            }
            else
            {
                lblCurr.Text = "1";
            }

            sortExpression = this.dtlSalesAgentStudentCourse.Attributes["SortExpression"];
            sortDirection = this.dtlSalesAgentStudentCourse.Attributes["SortDirection"];
            try
            {
                pds.DataSource = studentManager.GetCourseListInfo(studentUserID, sortExpression, sortDirection);//获取数据源

                dtlSalesAgentStudentCourse.DataSource = pds;//获取数据源
                //dtlSalesAgentStudentCourse.DataKeyNames = new string[] { "course_Name" };
                dtlSalesAgentStudentCourse.DataBind();//绑定数据
            }
            catch
            {
                windowsJs.Alert(this.Page, GetResourceString("failedGetCourseInfo"));
                return;
            }
            //Commented by AYZ 12/31/2016
            //catch  
            //{
            //    windowsJs.Alert(this.Page, "您选择的课程数据获取失败，请与系统管理员联系。");
            //    return;
            //}
        }
        #endregion

        #region 获取记录总数和页数
        /// <summary>
        /// 获取记录总数和页数
        /// </summary>
        private void InitCategory()
        {         
            // 数据总数
            int recordcount = pds.DataSourceCount;
            // 数据总数
            if (Request.Cookies["abc"] == null)
            {
                pagesize = Convert.ToInt32(ViewState["pagesize"]);//页面初始化时PageSize的值
            }
            else
            {
                HttpCookie cookie = Request.Cookies["abc"];
                pagesize = Convert.ToInt32(cookie.Value);
                ddlPageNum.SelectedValue = cookie.Value;
            }
             
            // 根据数据总数和每页显示的数据数，计算出总页数
            int pagecount = recordcount % pagesize == 0 ? recordcount / pagesize : recordcount / pagesize + 1;
            lblSum.Text = pagecount.ToString();

            //分页各按钮状态设定
            ChangeState();

            //跳转页下拉控件添加页号
            ddlPage.Items.Clear();
            for (int i = 1; i <= pagecount; i++)
            {
                ListItem li = new ListItem();
                li.Value = i.ToString();
                li.Text = i.ToString();

                ddlPage.Items.Add(li);
            }
        }
        #endregion

        #region 按钮状态改变
        /// <summary>
        /// 按钮状态改变事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lbtnFirst_Command(object sender, CommandEventArgs e)
        {
            int temp = 0;
            switch (e.CommandName)
            {
                // "首页"按下
                case "first": lblCurr.Text = "1";
                    lblCurr.Text = "1";
                    ddlPage.SelectedValue = "1";
                    break;
                // "前页"按下
                case "prev":
                    temp = Convert.ToInt32(lblCurr.Text) - 1;
                    lblCurr.Text = temp.ToString();
                    ddlPage.SelectedValue = temp.ToString();
                    break;
                // "下页"按下
                case "next":
                    temp = Convert.ToInt32(lblCurr.Text) + 1;
                    lblCurr.Text = temp.ToString();
                    ddlPage.SelectedValue = temp.ToString();
                    break;
                // "末页"按下
                case "last": lblCurr.Text = lblSum.Text;
                    temp = Convert.ToInt32(lblSum.Text);
                    lblCurr.Text = temp.ToString();
                    ddlPage.SelectedValue = temp.ToString();
                    break;
            }
            // 各按钮状态改变
            ChangeState();
            // 数据再绑定
            BindCxInfoData(Convert.ToInt32(lblCurr.Text), ddlStudentName.SelectedItem.Value);
        }

        /// <summary>
        /// 按钮状态改变
        /// </summary>
        private void ChangeState()
        {
            lbtnFirst.Enabled = true;
            lbtnPrev.Enabled = true;
            lbtnNext.Enabled = true;
            lbtnLast.Enabled = true;
            ddlPage.Enabled = true;

            // 数据总数为0 或1 的情况
            if (lblSum.Text == "0" || lblSum.Text == "1")
            {
                if (lblSum.Text == "0")
                {
                    lblCurr.Text = "0";
                    ddlPage.Enabled = false;
                }
                else
                {
                    lblCurr.Text = "1";
                }
                lbtnFirst.Enabled = false;
                lbtnPrev.Enabled = false;
                lbtnNext.Enabled = false;
                lbtnLast.Enabled = false;
            }
            // 当前页为第一页
            else if (lblCurr.Text == "1")
            {
                lbtnFirst.Enabled = false;
                lbtnPrev.Enabled = false;
            }
            // 当前页为末页
            else if (lblSum.Text == lblCurr.Text)
            {

                lbtnNext.Enabled = false;
                lbtnLast.Enabled = false;
            }

        }
        #endregion

        #region 跳转页事件
        /// <summary>
        /// 跳转页事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlPage_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindCxInfoData(Convert.ToInt32(ddlPage.SelectedValue), ddlStudentName.SelectedItem.Value);
            lblCurr.Text = ddlPage.SelectedValue.ToString();
            ChangeState();
        }
        #endregion

        #region 序号显示
        /// <summary>
        /// 序号显示
        /// </summary>
        /// <param name="pageindex">分页中的当前页号</param>
        private void RowDataBound(int pageindex, GridViewRowEventArgs e)
        {
            //// 分页每页显示的数据
            //if (e.Row.RowIndex != -1)
            //{
            //    // 每行的序号计算
            //    int indexID = 0;
            //    indexID = (pageindex - 1) * pagesize + e.Row.RowIndex + 1;
            //    // 首页的情况
            //    if (pageindex == 1)
            //    {
            //        indexID = e.Row.RowIndex + 1;
            //    }
            //    // 第一列显示序号
            //    e.Row.Cells[1].Text = indexID.ToString();
            //}
        }
        #endregion

        #region GridView行绑定事件
        /// <summary>
        /// GridView行绑定事件
        /// </summary>
        /// <param name="pageindex"></param>
        protected void GridViewForCourse_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //Gridview序号显示

            // 分页中的当前页号
            int pageindex = pds.CurrentPageIndex + 1;
            RowDataBound(pageindex, e);

            if (e.Row.RowType == DataControlRowType.Pager)
            {
                return;
            }

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //如果时间是1900或者为空的显示无
                string time1 = managerManager.UpdateTime(e.Row.Cells[1].Text, HttpContext.Current.Session["PreferredCulture"].ToString().ToUpper());
                e.Row.Cells[1].Text = time1;
                //commented by AYZ 1/14/2017
                //string time2 = managerManager.UpdateTime(e.Row.Cells[2].Text, HttpContext.Current.Session["PreferredCulture"].ToString().ToUpper());
                //e.Row.Cells[2].Text = time2;
            }
        }
        #endregion

        

        #region 每页显示数变化时
        /// <summary>
        /// 每页显示数变化时
        /// </summary>
        /// <param name="pageindex"></param>
        protected void ddlPageNum_SelectedIndexChanged(object sender, EventArgs e)
        {
            ViewState["pagesize"] = Convert.ToInt32(ddlPageNum.SelectedItem.Value);

            HttpCookie cookie = Request.Cookies["abc"];
            if (cookie != null)
            {
                //重新记忆 ddlPageNum 的值
                cookie.Value = ddlPageNum.SelectedItem.Value;
            }
            else
            {
                //cookie1的值为空new对象给cookie1
                cookie = new HttpCookie("abc");
                cookie.Value = ddlPageNum.SelectedItem.Value;
            }
            //设置cookie的生命周期
            cookie.Expires = DateTime.MaxValue;

            //将Cookie提交到浏览器
            Response.Cookies.Add(cookie);

            //任务信息数据加载
            BindCxInfoData(0, ddlStudentName.SelectedItem.Value);

            // 分页按钮部分初期化
            InitCategory();
        }
        #endregion
        #region ToolTip生成方法
        /// <summary>
        /// ToolTip生成方法
        /// </summary>
        /// <param name="pageindex"></param>
        protected void setToolTip(int index, int length, GridViewRowEventArgs e)
        {
            string strContent = e.Row.Cells[index].Text;
            if (strContent.Length > length)
            {
                e.Row.Cells[index].Text = strContent.Substring(0, length) + "...";
                e.Row.Cells[index].ToolTip = strContent;
            }

        }
        #endregion

        /*
        #region 排序处理
        /// <summary>
        /// 排序处理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GridViewForStudentCourse_Sorting(object sender, GridViewSortEventArgs e)
        {
            if (GridViewForCourseList.Rows.Count > 0)
            {

                //获取排序数据列
                sortExpression = e.SortExpression.ToString();
                //假定为排序方向为“顺序”
                sortDirection = "ASC";
                // “ASC”与事件参数获取到的排序方向进行比较，进行GridView排序方向参数的修改
                if (sortExpression == this.GridViewForCourseList.Attributes["SortExpression"])
                {
                    //获得下一次的排序状态
                    sortDirection = (this.GridViewForCourseList.Attributes["SortDirection"].ToString() == sortDirection ? "DESC" : "ASC");
                }
                // 重新设定GridView排序数据列及排序方向
                this.GridViewForCourseList.Attributes["SortExpression"] = sortExpression;
                this.GridViewForCourseList.Attributes["SortDirection"] = sortDirection;

                BindCxInfoData(Convert.ToInt32(ddlPage.SelectedValue));

                //SortForImage(sortDirection, sortExpression);
            }
        }
        #endregion
         * */
        protected void Item_Bound(Object sender, DataListItemEventArgs e)
        {
            // set background to light gray for odd row
            if (e.Item.ItemType == ListItemType.Item)
            {
                e.Item.BackColor = System.Drawing.Color.LightGray;
            }
            // set no record display info
            if (e.Item.ItemType == ListItemType.Footer)
            {
                if (pds.Count <= 0)
                {
                    ((Label)e.Item.FindControl("lblNoRecord")).Visible = true;
                }
            }
        }

        #region HEAD部学生List变化时
        /// <summary>
        /// HEAD部学生List变化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlStudentName_SelectedIndexChanged(object sender, EventArgs e)
        {
            // 取得学生ID
            if (ddlStudentName.SelectedItem != null)
            {
                if (!string.IsNullOrEmpty(ddlStudentName.SelectedItem.Value))
                {
                    BindCxInfoData(0, ddlStudentName.SelectedItem.Value);
                }
            }

        }
        #endregion
    }
}